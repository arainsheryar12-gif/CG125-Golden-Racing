CG125 GOLDEN RACING — ANDROID STUDIO PROJECT

This is an Android WebView app wrapper for the playable CG125 Golden Edition 3D prototype.

IMPORTANT
- This ZIP is an Android Studio project, not a compiled APK.
- The project needs Android Studio / Android SDK and an internet connection for Gradle dependencies.
- The game also loads Three.js from jsDelivr CDN, so internet is required when playing.
- No Android SDK/Gradle build environment was available in the creation environment, so an APK could not be compiled here.

HOW TO BUILD THE APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the extracted folder (the one containing settings.gradle) in Android Studio.
4. Wait for Gradle Sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Usually:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. If asked, allow installation from that source.

APP DETAILS
Name: CG125 Golden Racing
Package: com.sheryar.cg125golden
Orientation: Landscape
Minimum Android: 6.0 (API 23)

GITHUB CLOUD BUILD
A GitHub Actions workflow is included at:
.github/workflows/android-apk.yml

After the project files are uploaded to a GitHub repository's main branch:
1. Open the repository's Actions tab.
2. Select "Build CG125 Golden Racing APK".
3. Tap "Run workflow" if it has not started automatically.
4. Open the completed workflow run.
5. Under Artifacts, download "CG125-Golden-Racing-APK".
6. Extract the downloaded artifact ZIP; install app-debug.apk on Android.
